require 'flickraw'
require 'cgi'
require 'csv'


name_specie = "sturnus vulgaris"
FlickRaw.api_key="ba21020f518d59d9d74b81af71b37e7c"
FlickRaw.shared_secret="35b1704d1c3e1e6d"

writer = CSV.open('flickr_data.csv', 'w')

(1..20).each do |it| 
  print it
  @list = flickr.photos.search(
  :text     => name_specie,
  :extras   => 'geo,machine_tags,date_taken',
  :has_geo  => '1',
  :per_page => '500',
  :page => it
  )
  
  writer << ['latitude','longitude','source','collection_date']
  @list.each do |photo|
    #print "#{photo['latitude']} \n"
    writer << [photo['latitude'],photo['longitude'],'flickr',photo['datetaken']]
  end
  
  if @list.count <499
    break
  end
  
end
writer.close

